STHpredictor
============

A Window based tool for predicting the prevalence of Soil Transmitted Dieases (Made for WHO, Geneva)
